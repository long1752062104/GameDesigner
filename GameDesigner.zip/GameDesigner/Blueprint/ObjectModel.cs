﻿namespace GameDesigner
{
    public enum ObjectModel
    {
        Class,
        Object,
        ValueType,
    }
}
﻿namespace GameDesigner.MathOperations
{
    [System.Serializable]
    public class Array
    {
        public System.Array array = null;
    }
}
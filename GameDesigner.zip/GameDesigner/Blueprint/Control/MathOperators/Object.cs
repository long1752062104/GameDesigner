﻿namespace GameDesigner.MathOperations
{
    [System.Serializable]
    public class Objects
    {
        public object _object = null;
        public UnityEngine.Object _Object = null;
    }
}
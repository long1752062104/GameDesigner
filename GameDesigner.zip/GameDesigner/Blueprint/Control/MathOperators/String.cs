﻿namespace GameDesigner.MathOperations
{
    [System.Serializable]
    public class String
    {
        public string m_String = "";

        /// <summary>
        /// 返回a+b
        /// </summary>
        static public string Adds(string a, string b)
        {
            return a + b;
        }
    }
}
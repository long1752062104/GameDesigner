﻿#if UNITY_STANDALONE || UNITY_ANDROID || UNITY_IOS || UNITY_WSA
namespace Net.UnityComponent
{
    /// <summary>
    /// 网络Transform同步组件基类
    /// </summary>
    public class NetworkTransform : NetworkTransformBase
    {
    }
}
#endif
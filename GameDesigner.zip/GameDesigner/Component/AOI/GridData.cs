﻿namespace Net.AOI
{
    public class GridData
    {
        public Grid oldGrid;
        public Grid newGrid;
        public IGridBody body;
    }
}
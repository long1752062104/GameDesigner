﻿namespace Net.Config
{
    public static class GlobalConfig
    {
        public static bool ThreadPoolRun;
    }
}

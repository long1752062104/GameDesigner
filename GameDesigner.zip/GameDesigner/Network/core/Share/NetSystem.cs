﻿namespace Net.Share
{
    /// <summary>
    /// 网络系统设置类型
    /// </summary>
    public class NetSystem
    {
        /// <summary>
        /// 允许玩家创建场景
        /// </summary>
        public static bool CreateScene = true;
    }
}

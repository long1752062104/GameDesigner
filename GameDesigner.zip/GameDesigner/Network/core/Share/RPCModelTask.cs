﻿namespace Net.Share
{
    public class RPCModelTask
    {
        public bool IsCompleted;
        public RPCModel model;
    }
}

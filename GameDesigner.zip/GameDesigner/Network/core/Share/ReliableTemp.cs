﻿namespace Net.Share
{
    public class ReliableTemp
    {
        public bool hasData;
        public byte[] buffer;
    }
}
